var blogModel = require('../models/blogModel');

module.exports.addBlog=function(req,res){
var blog=new blogModel();
blog.title=req.body.title;
blog.content=req.body.content;
blog.images=req.file.filename;
blog.createdby= req.body.createdby;
blog.autheName= req.body.autheName;
var uid=req.params.id;
console.log(uid);

blogModel.findOne(uid,function(err,blog){
	if(err){
		console.log('err',err)
	}else{
		if(!blog){
			blog.save(function(err,blog){
				if(err){
					res.send(err);
				}else{
					//res.send(person);
					console.log(blog);
					//res.redirect("/login")
				}
			});
		}else{
			res.send({error:"blog is already taken"});
		}
	}

})
}

