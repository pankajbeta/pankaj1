var Usermodel = require('../models/userModel');

module.exports.signup=function(req,res){
var user=new Usermodel();
user.name=req.body.name;
user.email=req.body.email;
user.password=req.body.password;
user.pic= req.file.filename;
Usermodel.findOne({email:req.body.email},function(err,person){
	if(err){
		console.log('err',err)
	}else{
		if(!person){
			user.save(function(err,person){
				if(err){
					res.send(err);
				}else{
					//res.send(person);
					console.log(person);
					//res.redirect("/login")
				}
			});
		}else{
			res.send({error:"Email is already taken"});
		}
	}

})
}

module.exports.login=function(req,res){
var email=req.body.email;
var password=req.body.password;
console.log(email);
			Usermodel.findOne({email:email},function(err,person){
				if(err){
					console.log('err',err);
					}
					else{
						if(person){
							if(person.password==password){
						  
						        console.log(person)
								//res.redirect('/home');
								//res.render('home',{title:"home", data:person.email});

							}
							else{
								//res.send({error:'incorrect password'});
								res.redirect('/login')
							}
						}else{
							//res.send({error:'User name or password is worng'})
								res.redirect('/login')

						}
					}
				})
     }
