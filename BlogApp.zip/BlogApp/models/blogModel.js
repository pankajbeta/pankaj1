var mongoose=require("mongoose");
var Schema= mongoose.Schema;

var BlogSchema=new Schema({
	title:String,
	content:String,
	images:String,
	tags:String,
	createdby:Number,
	updatedBy:Number,
	autheName:
})
var Blog = mongoose.model('blog', BlogSchema);
module.exports = Blog;
