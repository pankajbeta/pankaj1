var mime = require('mime-types')
var multer  = require('multer');
//var upload = multer({ dest: 'uploads/' });
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/uploads/')
    },
    filename: function (req, file, cb) {
    	console.log('file ',file);
        cb(null, Date.now()+'.'+mime.extension(file.mimetype));
    }
});
