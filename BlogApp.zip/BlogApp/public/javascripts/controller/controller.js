app.controller("HomeCtrl", function($scope){
	$scope.message="hiii";
});
app.controller("login", function($scope,$location,$http){
$scope.error='';
$scope.userLogin=function(){
	$http({
	method:"POST",
	url:'api/login',
	data:{email:$scope.email,password:$scope.password},
}).then(function successCallback(response) {
		if(response.data.error){
			$scope.error = response.data.error;
		}else{
			$location.path('/home');
		}
		console.log(response);
	}, function errorCallback(response) {
		console.log('error',response);
	});
};
});

app.controller("SignUp", function($scope,$location,$http){
$scope.uploadFile = function(){
        var file = $scope.registration.user.myFile;
      var uploadUrl = "api/signup";
        var fd = new FormData();
        fd.append('name',$scope.registration.user.name);
        fd.append('email',$scope.registration.user.email);
        fd.append('password',$scope.registration.user.password);
        fd.append('file', file);
        //JSON.stringify({name:$scope.registration.user.name,email:$scope.registration.user.email,password:$scope.registration.user.password, file:file})
        $http.post(uploadUrl,fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        }) .success(function(){
          console.log("success!!");
          $location.path("/login")
        })
        .error(function(){
          console.log("error!!");
        });
    };
});

app.controller("blogView", function($scope,$http){
	$scope.blogFile = function(){
        var file = $scope.myFile;
      var uploadUrl = "api/addBlog";
        var fd = new FormData();
        fd.append('title',$scope.title);
        fd.append('content',$scope.content);
        fd.append('file', file);
        //JSON.stringify({name:$scope.registration.user.name,email:$scope.registration.user.email,password:$scope.registration.user.password, file:file})
        $http.post(uploadUrl,fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        }) .success(function(){
          console.log("success!!");
          $location.path("/list")
        })
        .error(function(){
          console.log("error!!");
        });
    };
});

