var app =angular.module('myApp', ['ngRoute' ,'ngMessages'])
    app.config(['$routeProvider','$locationProvider', function($routeProvider,$locationProvider) {
        $routeProvider.
                when('/home', {
                 	templateUrl: 'javascripts/view/home.html', 
                     controller: 'HomeCtrl'
                   }).
                when('/blog', {
                 	templateUrl: 'javascripts/view/blog.html', 
                     controller: 'HomeCtrl'
                   }).
                when('/singel-blogview', {
                 	templateUrl: 'javascripts/view/singel-blogview.html', 
                     controller: 'blogView'
                   }).
                 when('/add', {
                 	templateUrl: 'javascripts/view/add.html', 
                     controller: 'blogView'
                   }).
                 when('/list', {
                 	templateUrl: 'javascripts/view/list.html', 
                     controller: 'blogView'
                   }) .
                   when('/contactUs', {
                 	templateUrl: 'javascripts/view/contactUs.html', 
                     controller: 'blogView'
                   })
                    .
                   when('/signUp', {
                 	templateUrl: 'javascripts/view/signup.html', 
                     controller: 'SignUp'
                   }).
                   when('/login', {
                 	templateUrl: 'javascripts/view/login.html', 
                     controller: 'login'
                   }).
                otherwise({
                redirectTo: '/home'
                });
                $locationProvider.html5Mode({
             enabled: true,
                requireBase: false
              });

}]);

app.directive('compareTo', [function() {
    return {
        require: "ngModel",
        scope: {
            otherModelValue: "=compareTo"
        },
        link: function(scope, element, attributes, ngModel) {
             
            ngModel.$validators.compareTo = function(modelValue) {
                return modelValue == scope.otherModelValue;
            };
 
            scope.$watch("otherModelValue", function() {
                ngModel.$validate();
            });
        }
    };
}]); 
app.directive('fileModel', ['$parse', function ($parse) {
return {
    restrict: 'A',
    link: function(scope, element, attrs) {
        var model = $parse(attrs.fileModel);
        var modelSetter = model.assign;

        element.bind('change', function(){
            scope.$apply(function(){
                modelSetter(scope, element[0].files[0]);
            });
        });
    }
};
}]);