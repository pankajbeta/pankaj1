app.service('addUser',['$http',function($http){
this.post=function(uploadUrl,data){
var fd= new FormData();
for(var i in data){
	fd.append(i,data[i]);
	$http.post(uploadUrl,fd,{
		transFormRequest:angular.indentity,
		header:{'Content-Type':undefined}
	})
}
}
}])

