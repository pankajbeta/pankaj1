app.service('createUser',function(){
var uid=1;
var userInfo=[{
		id: null,
		name: null,
		email: null,
		password: null,
		image: null
	
	}];
this.saveUser=function(user){
     if(userInfo.id == null){
      user.id +=uid;
   userInfo.push(user);
		}else{
			for(i in userInfo){
				if(userInfo[i].id == data.id){
					userInfo[i] == data
				}
			}
		}
	}


this.list=function(){
	return userInfo;
}

this.delete=function(id){
	for(i in userInfo){
		if(userInfo[i].id == id){
			userInfo.splice(i,1);
		}
	}
}

his.getData = function (id) {
        for (i in userInfo) {
            if (userInfo[i].id == id) {
                return userInfo[i];
            }
        }

    }