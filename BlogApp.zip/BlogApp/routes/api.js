var express = require('express');
var router = express.Router();
var mime = require('mime-types')
var multer  = require('multer');
//var upload = multer({ dest: 'uploads/' });
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/uploads/')
    },
    filename: function (req, file, cb) {
    	console.log('file ',file);
        cb(null, Date.now()+'.'+mime.extension(file.mimetype));
    }
});
var upload = multer({ storage: storage });

/* GET home page. */
var userController=require('../controller/userController');
var blogController=require('../controller/blogController');

router.post('/login',userController.login);
router.post('/signup',upload.single('file'),userController.signup);
router.post('/addBlog',upload.single('file'),blogController.addBlog);

module.exports = router;
