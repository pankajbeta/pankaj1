// it get the data from api js and save it in the data base
//model
var Usermodel = require('../model/usermodel');
var Usermodelo = require('../model/usermodelo');
// sign up is get from api.js
module.exports.signup =  function(req, res) {

    var user = new Usermodel();
    user.name = req.body.name;
    user.email = req.body.email;
    user.password = req.body.password;
     user.file = req.file.filename;
//console.log(req.body);

    Usermodel.findOne({email:req.body.email},function(err,person){
    	if(err){
    		console.log('err',err)
    	}else {
    		if(!person){
			    user.save(function (err, data) {
					if (err) {
						res.send(err);
					}else {
						console.log("success");
						//res.redirect('/login');
						res.send(data);
					}
				});
			}else{
				res.send({error:'Email is already register'});
			}
		}
	});
} 



// for login
module.exports.login =function(req,res){

	var email = req.body.email;
	var password = req.body.password;
	 
	Usermodel.findOne({email:email},function(err,person){
    	if(err){
    		console.log('err',err)
    	}else {
    		if(person){
    			if(person.password==password){
    				res.send(person);
    			}else{
    				res.send({error:'Incorrect Password'});
    			}
    		}else{
    			res.send({error:'Email is not Register'});
    		}
    	}
    });
}

// for add in list
module.exports.add =  function(req, res) {

    var blog = new Usermodelo();
    blog.title = req.body.title;
    blog.content = req.body.content;

    Usermodelo.findOne({title:req.body.title},function(err,doc){
    	if(err){
    		console.log('err',err)
    	}else {
    		if(!doc){
			    blog.save(function (err, data) {
					if (err) {
						res.send(err);
					}else {
						console.log("success");
						//res.redirect('/login');
						res.send(data);
					}
				});
			}else{
				res.send({error:'title is already register'});
			}
		}
	});
} 
//view all user
module.exports.list = function(req,res){

	Usermodelo.find({},function(err,blogs){
		if(err){
			res.send(err);
		}else{
			res.send(blogs);
		}
	});
}
