var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var blogSchema = new Schema({
 title: String,
content: String,
});



var blog = mongoose.model('blogs', blogSchema);

module.exports = blog;
