app.controller('blogcont',function($scope){
	
})
//for login***************************************************************
 app.controller('ulogin',['$scope','$location','$http',
 function ($scope,$location,$http) {
$scope.logOut=true; 
$scope.message="helloo";
$scope.clickCreateUser=true;

$scope.error = '';

 $scope.userlogin=function(){
	   

	$scope.error = '';
 	$http({
	  method: 'POST',
	  url: '/api/login',
	   //url means fetch data from api.js /sign up
	  data: {email:$scope.email, password:$scope.pass},
	}).then(function successCallback(response) {
		if(response.data.error){
			$scope.error = response.data.error;
		}else if(response.data.status==true){
			
			$location.path('/register');

		}
		console.log()
	    console.log(response);
	}, function errorCallback(response) {
	    console.log('error',response);
	});
 }
}]);
//for register by multer***************************************************
app.controller('registerCtrl',['$scope','$location','$http',function($scope,$location,$http){
$scope.uploadFile = function(){
        var file = $scope.myFile;
      var uploadUrl = "api/signup";
        var fd = new FormData();
        fd.append('name',$scope.name);
        fd.append('email',$scope.email);
        fd.append('password',$scope.password);
        fd.append('file', file);
        //JSON.stringify({name:$scope.registration.user.name,email:$scope.registration.user.email,password:$scope.registration.user.password, file:file})
        $http.post(uploadUrl,fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        }) .success(function(){
          console.log("success!!");
          $location.path("/login")
        })
        .error(function(){
          console.log("error!!");
        });
    };

}])
/*
//for register*****************************************************
app.controller('registerCtrl',['$scope','$location','$http',function($scope,$location,$http){
	
	$scope.signUpUser=function(){
 	$scope.error = '';
	$http({
		method: 'POST',
		url: '/api/signup',
		data: {name:$scope.name,email:$scope.email, password:$scope.password},
	}).then(function successCallback(response) {
		if(response.data.error){
			$scope.error = response.data.error;
		}else{
			$location.path('/login');
			//console.log("hi");
		}
		//console.log(response);
	}, function errorCallback(response) {
		console.log('error',response);
	});
	
}
}]); */
//for add
app.controller('addcont',['$scope','$location','$http',function($scope,$location,$http){
	
	$scope.addBlog=function(){
 	$scope.error = '';
	$http({
		method: 'POST',
		url: '/api/add',
		data: {title:$scope.title,content:$scope.content},
	}).then(function successCallback(response) {
		if(response.data.error){
			$scope.error = response.data.error;
		}else{
			$location.path('/list');
			//console.log("hi");
		}
		//console.log(response);
	}, function errorCallback(response) {
		console.log('error',response);
	});
	
}
}]);


// view alll controller
app.controller('viewController', function ($scope,$http) {

$http({
	  method: 'GET',
	  url: '/api/list'
	  //list is the router which is given in the api
	}).then(function successCallback(response) {
	    if(response.data){
	    	$scope.users = response.data;
	    }
	}, function errorCallback(response) {
	    console.log('error',response);
	});
});



	