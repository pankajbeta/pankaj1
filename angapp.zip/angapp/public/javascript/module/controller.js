
//for login***************************************************************
 app.controller('ulogin',['$scope','$location','$http',
 function ($scope,$location,$http) {
$scope.logOut=true; 
$scope.message="helloo";
$scope.clickCreateUser=true;

$scope.error = '';

 $scope.userlogin=function(){
	   

	$scope.error = '';
 	$http({
	  method: 'POST',
	  url: '/api/login',
	   //url means fetch data from api.js /sign up
	  data: {email:$scope.email, password:$scope.pass},
	}).then(function successCallback(response) {
		if(response.data.error){
			$scope.error = response.data.error;
		}else if(response.data.status==true){
			
			$location.path('/list');

		}
	    console.log(response);
	}, function errorCallback(response) {
	    console.log('error',response);
	});
 }
}]);
  

//for register*****************************************************
app.controller('registerCtrl',function($scope,$location,$http){
	  $scope.signUpUser=function(){
 	$scope.error = '';
	$http({
		method: 'POST',
		url: '/api/signup',
		data: {name:$scope.name,email:$scope.email, password:$scope.password},
	}).then(function successCallback(response) {
		if(response.data.error){
			$scope.error = response.data.error;
		}else{
			$location.path('/login');
			console.log("hi");
		}
		console.log(response);
	}, function errorCallback(response) {
		console.log('error',response);
	});
}})








