var app= angular.module('myapp',['ngRoute']);
app.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
	when('/', {
        templateUrl: 'javascript/view/home2.html',
        controller: 'blogcont'
      }).
      when('/list', {
        templateUrl: 'javascript/view/list.html',
        controller: 'blogcont'
      }).
      when('/login', {
        templateUrl: 'javascript/view/login.html',
        controller: 'ulogin'
      }).
	  when('/add', {
        templateUrl: 'javascript/view/add.html',
        controller: 'addcont'
	  }).
	  when('/list', {
        templateUrl: 'javascript/view/list.html',
        controller: 'viewController'
	  }).
	  when('/blog', {
        templateUrl: 'javascript/view/blog.html',
        controller: 'blogcont'
	  }).
	  when('/register', {
        templateUrl: 'javascript/view/register.html',
        controller: 'registerCtrl'
	  })
	  .
	  when('/contact', {
        templateUrl: 'javascript/view/contact.html',
        controller: 'registerCtrl'
	  }).
      otherwise({
        redirectTo: '/home2'
      });
	  
  }]);
  
  
// directive for save file*****************************************************
app.directive('fileModel', ['$parse', function ($parse) {
return {
    restrict: 'A',
    link: function(scope, element, attrs) {
        var model = $parse(attrs.fileModel);
        var modelSetter = model.assign;

        element.bind('change', function(){
            scope.$apply(function(){
                modelSetter(scope, element[0].files[0]);
            });
        });
    }
};
}]);
