var app= angular.module('myapp',['ngRoute']);
app.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
	when('/home2', {
        templateUrl: 'javascript/view/home2.html',
        controller: 'blogcont'
      }).
      when('/list', {
        templateUrl: 'javascript/view/list.html',
        controller: 'blogcont'
      }).
      when('/login', {
        templateUrl: 'javascript/view/login.html',
        controller: 'ulogin'
      }).
	  when('/add', {
        templateUrl: 'javascript/view/add.html',
        controller: 'blogcont'
	  }).
	  when('/list', {
        templateUrl: 'javascript/view/list.html',
        controller: 'blogcont'
	  }).
	  when('/blog', {
        templateUrl: 'javascript/view/blog.html',
        controller: 'blogcont'
	  }).
	  when('/register', {
        templateUrl: 'javascript/view/register.html',
        controller: 'registerCtrl'
	  }).
      otherwise({
        redirectTo: '/home2'
      });
	  
  }]);
  