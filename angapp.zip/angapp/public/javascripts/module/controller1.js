app.controller('blogcont',function($scope){

});
