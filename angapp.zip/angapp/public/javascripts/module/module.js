var app= angular.module('myapp',['ngRoute']);
app.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
      when('/list', {
        templateUrl: 'javascripts/view/list.html',
        controller: 'blogcont'
      }).
      when('/login', {
        templateUrl: 'javascripts/view/login.html',
        controller: 'blogcont'
      }).
      otherwise({
        redirectTo: '/home'
      });
  }]);
  