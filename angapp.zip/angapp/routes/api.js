var express = require('express');
var router = express.Router();



// controllers

var userController = require('../controller/userController');



// routes 

router.post('/signup',userController.signup);
//sign up is function name in usercontroller.js
router.post('/login',userController.login);



module.exports = router;