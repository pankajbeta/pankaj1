var express = require('express');
var router = express.Router();
var users=require('../model/usermodel');//1
var auth = require('./auth');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});
router.get('/login', function(req, res, next) {
  res.render('login', { title: 'login' });
});
router.get('/home',auth.authn ,function(req, res, next) {
  res.render('home', {user : req.session.username});
});
router.get('/signup', function(req, res, next) {
  res.render('signup', { title: 'signupuu' });
});

/*router.post('/signup', function(req, res, next) {
  res.render('signup', { title: 'signup' });
});*/
//*********************for save data in **********************************************
router.post('/signup', function(req, res) {
 console.log(req.body);

 var user = new users();//get form 1st 
 console.log(user);
 user.firstname=req.body.firstname;
 user.message=req.body.message;
 user.email=req.body.email;
 user.password = req.body.password;
 user.save(function(err,data){
	if(err){
		res.send(err);
	}else{
		res.send(data);
		//res.redirect('/viewalluser');
	}
 });
});
//************************************** view all user*******************************
router.get('/viewalluser', function(req, res, next) {
users.find({},function(err,person){
	if(err){
		res.send(err);
	}
	else
	{
		//res.send(person);
		res.render('viewtab',{title:"view",data:person});
	}
});
});
//***********************************for login check*******************************
router.post('/login', function(req, res) {
	var email = req.body.email;
	var password = req.body.password;
	 
	users.findOne({email:email},function(err,person){
    	if(err){
    		console.log('err',err) 
    	}else {
    		if(person){
    			if(person.password==password){
    				req.session.username = person; 
					//res.send({status:true,data:person});
					//res.redirect('/viewalluser');
					res.redirect('/home');
    			}else{
    				res.send({error:'Incorrect Password'});
    			}
    		}else{
    			res.send({error:'Email is not Register'});
    		}
    	}
    });
});
//**********************************for delete*********************************
router.get('/delete/:id',function ( req, res ){
  users.findById( req.params.id, function ( err, person ){
    person.remove( function ( err, person ){
      res.redirect( '/viewalluser' );
    });
  });
});
//function from dreamer slab.com  to do list in mongoose js
 //exports.destroy = function ( req, res ){
//  Todo.findById( req.params.id, function ( err, todo ){
  //  todo.remove( function ( err, todo ){
      //res.redirect( '/' );
    //});
  //});
//}; 

//*****************************for edit in todo**********************************************
router.get('/edit/:id',function ( req, res ){
	var uid=req.params.id;
	users.findById(uid, function ( err, person ){
		console.log("1111111");
     res.render( 'edit',{data:person});
    });
  });

  
router.post('/edit/:id',function ( req, res ){
	var uid=req.params.id;
	users.findById(uid, function (err, person ){
   person.firstname=req.body.firstname;
   person.save(function ( err, person ){
     res.redirect( '/viewalluser' );
	 
   })
    });
  });
//*******************************for routing**************************************************
module.exports = router;
