var app =angular.module('myApp',[]);
app.controller("mycontroller",function($scope){
	$scope.myObj=[{
      name:"mnagal",
      phone:9592329449,
      message:"hloo"
	}];
	$scope.myarray=[]
	$scope.save=function(){
$scope.myObj.push({name:$scope.name,phone:$scope.phone,message:$scope.message});
console.log($scope.myObj);
$scope.name="";
$scope.phone="";
$scope.message="";
$scope.myarray=$scope.myObj;
	}
});
