app.controller('mycontroller',['$scope','$location',function($scope,$location){
    $scope.names=[
	{name:'Pankaj',phoneNumber:9988471234},
	{name:'Pappu',phoneNumber:998875599},
	{name:'Rohit',phoneNumber:959234239}
	];
  $scope.addperson=function(){
	$scope.names.push({
  name:$scope.fname, phoneNumber:$scope.pnumber});
	$scope.fname="";
	$scope.pnumber="";
	$location.path('/view');
	}
$scope.removeProduct=function(name){
	$scope.names.pop(name);
	};

}]);



